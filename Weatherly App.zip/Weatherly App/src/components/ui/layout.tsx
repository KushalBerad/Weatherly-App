import type { PropsWithChildren } from "react";
import Header from "./header";

const Layout = ({ children }: PropsWithChildren) => {
    return (
        <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-muted">
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
                {children}
            </main>

            {/* Tip Bar */}
            <div className="w-full bg-indigo-700 text-indigo-200 py-2 text-center font-semibold animate-pulse select-none">
                🌦️ Tip: Don't Forget to Carry an umbrella on rainy days! Stay safe and dry!
            </div>

            {/* Footer */}
            <footer className="w-full bg-gradient-to-r from-indigo-700 via-blue-700 to-sky-600 
                bg-opacity-95 backdrop-blur-md border-t shadow-md">
                <div className="container mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center gap-3 text-sm text-white/80">
                    <div className="flex items-center gap-2 font-bold text-white drop-shadow-md">
                        <span className="animate-spin-slow">☀️</span>
                        <span className="animate-bounce">🌧️</span>
                        <span className="text-lg">Weatherly</span>
                    </div>
                    <div className="text-center md:text-right">
                        © {new Date().getFullYear()} Weatherly. Made with{" "}
                        <span className="text-red-400">♥</span> &nbsp;|&nbsp;{" "}
                        <a
                            href="https://github.com/KushalBerad"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline hover:text-yellow-300"
                        >
                            GitHub
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default Layout;

import type { ForecastData } from "@/api/types";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { ArrowDown, ArrowUp, Droplets, Wind } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

interface WeatherForecastProps {
    data: ForecastData;
}

interface DailyForecast {
    date: number;
    temp_min: number;
    temp_max: number;
    humiditySum: number;
    windSum: number;
    count: number;
    weather: {
        id: number;
        main: string;
        description: string;
        icon: string;
    };
}

const WeatherForecast = ({ data }: WeatherForecastProps) => {
    const [viewMode, setViewMode] = useState<"cards" | "chart">("cards");

    // Group 3-hourly forecasts into daily summaries
    const dailyForecast = data.list.reduce((acc, forecast) => {
        const dateKey = format(new Date(forecast.dt * 1000), "yyyy-MM-dd");

        if (!acc[dateKey]) {
            acc[dateKey] = {
                date: forecast.dt,
                temp_min: forecast.main.temp_min,
                temp_max: forecast.main.temp_max,
                humiditySum: forecast.main.humidity,
                windSum: forecast.wind.speed,
                count: 1,
                weather: forecast.weather[0],
            };
        } else {
            acc[dateKey].temp_min = Math.min(
                acc[dateKey].temp_min,
                forecast.main.temp_min
            );
            acc[dateKey].temp_max = Math.max(
                acc[dateKey].temp_max,
                forecast.main.temp_max
            );
            acc[dateKey].humiditySum += forecast.main.humidity;
            acc[dateKey].windSum += forecast.wind.speed;
            acc[dateKey].count += 1;
        }
        return acc;
    }, {} as Record<string, DailyForecast>);

    // Take next 5 days
    const nextDays = Object.values(dailyForecast).slice(0, 5);

    const formatTemp = (temp: number) => `${Math.round(temp)}°`;

    // Chart Data
    const chartData = nextDays.map((day) => ({
        date: format(new Date(day.date * 1000), "EEE"),
        min: Math.round(day.temp_min),
        max: Math.round(day.temp_max),
        humidity: Math.round(day.humiditySum / day.count),
        wind: parseFloat((day.windSum / day.count).toFixed(1)),
    }));

    return (
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-bold text-blue-600 dark:text-blue-300">
                    5-Day Forecast
                </CardTitle>

                {/* Toggle buttons */}
                <div className="flex gap-2">
                    <button
                        onClick={() => setViewMode("cards")}
                        className={`px-3 py-1 rounded-lg text-sm font-semibold ${viewMode === "cards"
                                ? "bg-blue-600 text-white"
                                : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
                            }`}
                    >
                        Cards
                    </button>
                    <button
                        onClick={() => setViewMode("chart")}
                        className={`px-3 py-1 rounded-lg text-sm font-semibold ${viewMode === "chart"
                                ? "bg-blue-600 text-white"
                                : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
                            }`}
                    >
                        Chart
                    </button>
                </div>
            </CardHeader>

            <CardContent>
                {viewMode === "cards" ? (
                    <div className="grid gap-6">
                        {nextDays.map((day, index) => {
                            const avgHumidity = Math.round(day.humiditySum / day.count);
                            const avgWind = (day.windSum / day.count).toFixed(1);

                            return (
                                <motion.div
                                    key={day.date}
                                    className="grid grid-cols-3 items-center gap-4 rounded-xl border p-4 bg-white/40 dark:bg-gray-800/40 shadow-md hover:shadow-lg transition-all"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                >
                                    {/* Date + Condition */}
                                    <div className="flex items-center gap-3">
                                        <img
                                            src={`https://openweathermap.org/img/wn/${day.weather.icon}@2x.png`}
                                            alt={day.weather.description}
                                            className="h-10 w-10"
                                        />
                                        <div>
                                            <p className="font-medium">
                                                {format(new Date(day.date * 1000), "EEE, MMM d")}
                                            </p>
                                            <p className="text-sm text-muted-foreground capitalize">
                                                {day.weather.description}
                                            </p>
                                        </div>
                                    </div>

                                    {/* Temps */}
                                    <div className="flex justify-center gap-6">
                                        <span className="flex items-center text-blue-500">
                                            <ArrowDown className="mr-1 h-4 w-4" />
                                            {formatTemp(day.temp_min)}
                                        </span>
                                        <span className="flex items-center text-red-500">
                                            <ArrowUp className="mr-1 h-4 w-4" />
                                            {formatTemp(day.temp_max)}
                                        </span>
                                    </div>

                                    {/* Humidity + Wind */}
                                    <div className="flex justify-end gap-6">
                                        <span className="flex items-center gap-1">
                                            <Droplets className="h-4 w-4 text-blue-500" />
                                            <span className="text-sm">{avgHumidity}%</span>
                                        </span>
                                        <span className="flex items-center gap-1">
                                            <Wind className="h-4 w-4 text-blue-500" />
                                            <span className="text-sm">{avgWind} m/s</span>
                                        </span>
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col gap-6">
                        {/* Chart */}
                        <div className="h-[250px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={chartData}>
                                    <XAxis
                                        dataKey="date"
                                        stroke="#888888"
                                        fontSize={12}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <YAxis
                                        stroke="#888888"
                                        fontSize={12}
                                        tickLine={false}
                                        axisLine={false}
                                        tickFormatter={(value) => `${value}°`}
                                    />
                                    <Tooltip />
                                    <Line
                                        type="monotone"
                                        dataKey="min"
                                        stroke="#2563eb"
                                        strokeWidth={2}
                                        dot
                                        name="Min Temp"
                                    />
                                    <Line
                                        type="monotone"
                                        dataKey="max"
                                        stroke="#ef4444"
                                        strokeWidth={2}
                                        dot
                                        name="Max Temp"
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>

                        {/* Summary Section */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-center">
                            <div className="p-3 rounded-lg bg-white/30 dark:bg-gray-800/40 shadow">
                                <p className="font-semibold text-blue-500">Avg Humidity</p>
                                <p>
                                    {Math.round(
                                        chartData.reduce((a, c) => a + c.humidity, 0) /
                                        chartData.length
                                    )}
                                    %
                                </p>
                            </div>
                            <div className="p-3 rounded-lg bg-white/30 dark:bg-gray-800/40 shadow">
                                <p className="font-semibold text-blue-500">Avg Wind</p>
                                <p>
                                    {(
                                        chartData.reduce((a, c) => a + c.wind, 0) /
                                        chartData.length
                                    ).toFixed(1)}{" "}
                                    m/s
                                </p>
                            </div>
                            <div className="p-3 rounded-lg bg-white/30 dark:bg-gray-800/40 shadow col-span-2">
                                <p className="font-semibold text-blue-500">Condition</p>
                                <p className="capitalize">
                                    {nextDays.map((d) => d.weather.main).join(", ")}
                                </p>
                            </div>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default WeatherForecast;

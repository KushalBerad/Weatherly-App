// import type { ForecastData } from "@/api/types";
// import { Card, CardContent, CardHeader, CardTitle } from "./card";
// import {
//     LineChart,
//     Tooltip,
//     XAxis,
//     YAxis,
//     Line,
//     ResponsiveContainer,
// } from "recharts";
// import { format } from "date-fns";
// import { useState } from "react";
// import { Button } from "./button";

// interface HourlyTemperatureProps {
//     data: ForecastData;
// }

// const HourlyTemperature = ({ data }: HourlyTemperatureProps) => {
//     const [view, setView] = useState<"temp" | "feels_like" | "pop" | "both">("temp");

//     // Next 12 hours
//     const chartData = data.list.slice(0, 12).map((item) => ({
//         time: format(new Date(item.dt * 1000), "ha"),
//         temp: Math.round(item.main.temp),
//         feels_like: Math.round(item.main.feels_like),
//         pop: Math.round((item.pop || 0) * 100), // precipitation probability (%)
//         icon: item.weather[0].icon,
//         desc: item.weather[0].description,
//     }));

//     return (
//         <Card className="flex-1 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900">
//             <CardHeader className="flex flex-col md:flex-row items-center justify-between gap-3">
//                 <CardTitle className="text-lg font-semibold">
//                     Hourly Trends
//                 </CardTitle>

//                 {/* Toggle Buttons */}
//                 <div className="flex flex-wrap gap-2">
//                     <Button
//                         variant={view === "temp" ? "default" : "outline"}
//                         size="sm"
//                         onClick={() => setView("temp")}
//                     >
//                         Temp
//                     </Button>
//                     <Button
//                         variant={view === "feels_like" ? "default" : "outline"}
//                         size="sm"
//                         onClick={() => setView("feels_like")}
//                     >
//                         Feels Like
//                     </Button>
//                     <Button
//                         variant={view === "pop" ? "default" : "outline"}
//                         size="sm"
//                         onClick={() => setView("pop")}
//                     >
//                         Rain %
//                     </Button>
//                     <Button
//                         variant={view === "both" ? "default" : "outline"}
//                         size="sm"
//                         onClick={() => setView("both")}
//                     >
//                         Both
//                     </Button>
//                 </div>
//             </CardHeader>

//             <CardContent>
//                 <div className="h-[250px] w-full">
//                     <ResponsiveContainer width="100%" height="100%">
//                         <LineChart
//                             data={chartData}
//                             margin={{ top: 20, right: 20, left: -10, bottom: 10 }}
//                         >
//                             {/* X-Axis */}
//                             <XAxis
//                                 dataKey="time"
//                                 stroke="#aaa"
//                                 fontSize={12}
//                                 tickLine={false}
//                                 axisLine={false}
//                             />

//                             {/* Y-Axis */}
//                             <YAxis
//                                 stroke="#aaa"
//                                 fontSize={12}
//                                 tickLine={false}
//                                 axisLine={false}
//                                 tickFormatter={(value) =>
//                                     view === "pop" ? `${value}%` : `${value}°`
//                                 }
//                             />

//                             {/* Tooltip */}
//                             <Tooltip
//                                 content={({ active, payload, label }) => {
//                                     if (active && payload && payload.length) {
//                                         const data = payload[0].payload;
//                                         return (
//                                             <div className="rounded-lg border bg-background p-3 shadow-md">
//                                                 <div className="flex items-center gap-2">
//                                                     <img
//                                                         src={`https://openweathermap.org/img/wn/${data.icon}.png`}
//                                                         alt={data.desc}
//                                                         className="h-6 w-6"
//                                                     />
//                                                     <span className="text-sm font-medium capitalize">
//                                                         {data.desc}
//                                                     </span>
//                                                 </div>
//                                                 <p className="text-xs text-muted-foreground mt-1">
//                                                     {label}
//                                                 </p>
//                                                 <div className="grid grid-cols-2 gap-2 mt-2">
//                                                     {(view === "temp" || view === "both") && (
//                                                         <div>
//                                                             <span className="text-[0.70rem] uppercase text-muted-foreground">
//                                                                 Temp
//                                                             </span>
//                                                             <p className="font-bold">{data.temp}°C</p>
//                                                         </div>
//                                                     )}
//                                                     {(view === "feels_like" || view === "both") && (
//                                                         <div>
//                                                             <span className="text-[0.70rem] uppercase text-muted-foreground">
//                                                                 Feels Like
//                                                             </span>
//                                                             <p>{data.feels_like}°C</p>
//                                                         </div>
//                                                     )}
//                                                     {view === "pop" && (
//                                                         <div>
//                                                             <span className="text-[0.70rem] uppercase text-muted-foreground">
//                                                                 Rain
//                                                             </span>
//                                                             <p>{data.pop}%</p>
//                                                         </div>
//                                                     )}
//                                                 </div>
//                                             </div>
//                                         );
//                                     }
//                                     return null;
//                                 }}
//                             />

//                             {/* Temp Line */}
//                             {(view === "temp" || view === "both") && (
//                                 <Line
//                                     type="monotone"
//                                     dataKey="temp"
//                                     stroke="#2563eb"
//                                     strokeWidth={3}
//                                     dot={false}
//                                     activeDot={{ r: 6, fill: "#2563eb" }}
//                                 />
//                             )}

//                             {/* Feels Like Line */}
//                             {(view === "feels_like" || view === "both") && (
//                                 <Line
//                                     type="monotone"
//                                     dataKey="feels_like"
//                                     stroke="#64748b"
//                                     strokeWidth={2}
//                                     dot={false}
//                                     strokeDasharray="5 5"
//                                 />
//                             )}

//                             {/* Rain % Line */}
//                             {view === "pop" && (
//                                 <Line
//                                     type="monotone"
//                                     dataKey="pop"
//                                     stroke="#22c55e"
//                                     strokeWidth={3}
//                                     dot={{ r: 4, fill: "#22c55e" }}
//                                     activeDot={{ r: 6 }}
//                                 />
//                             )}
//                         </LineChart>
//                     </ResponsiveContainer>
//                 </div>
//             </CardContent>
//         </Card>
//     );
// };

// export default HourlyTemperature;









import type { ForecastData } from "@/api/types";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import {
    LineChart,
    Tooltip,
    XAxis,
    YAxis,
    Line,
    ResponsiveContainer,
} from "recharts";
import { format } from "date-fns";
import { useState } from "react";
import { Button } from "./button";
import { motion } from "framer-motion";

interface HourlyTemperatureProps {
    data: ForecastData;
}

const HourlyTemperature = ({ data }: HourlyTemperatureProps) => {
    const [view, setView] = useState<"temp" | "feels_like" | "pop" | "both">("temp");

    // Next 12 hours
    const chartData = data.list.slice(0, 12).map(item => ({
        time: format(new Date(item.dt * 1000), "ha"),
        temp: Math.round(item.main.temp),
        feels_like: Math.round(item.main.feels_like),
        pop: Math.round((item.pop || 0) * 100), // precipitation probability (%)
        icon: item.weather[0].icon,
        desc: item.weather[0].description,
    }));

    return (
        <Card className="flex-1 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900">
            <CardHeader className="flex flex-col md:flex-row items-center justify-between gap-3">
                <CardTitle>
                    <motion.h3
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        Hourly Trends
                    </motion.h3>
                </CardTitle>
                <div className="flex gap-2">
                    <Button size="sm" variant={view === "temp" ? "default" : "outline"} onClick={() => setView("temp")}>Temp</Button>
                    <Button size="sm" variant={view === "feels_like" ? "default" : "outline"} onClick={() => setView("feels_like")}>Feels Like</Button>
                    <Button size="sm" variant={view === "pop" ? "default" : "outline"} onClick={() => setView("pop")}>Rain %</Button>
                    <Button size="sm" variant={view === "both" ? "default" : "outline"} onClick={() => setView("both")}>Both</Button>
                </div>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={chartData}>
                        <XAxis dataKey="time" />
                        <YAxis
                            domain={view === "pop" ? [0, 100] : ["auto", "auto"]}
                            unit={view === "pop" ? "%" : "°"}
                        />
                        <Tooltip
                            content={({ active, payload, label }) =>
                                active && payload && payload.length ? (
                                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-2 rounded bg-background shadow">
                                        <div className="font-medium">{payload[0].payload.desc}</div>
                                        <div className="text-xs">{label}</div>
                                        {(view === "temp" || view === "both") && (
                                            <div>Temp: {payload[0].payload.temp}°C</div>
                                        )}
                                        {(view === "feels_like" || view === "both") && (
                                            <div>Feels Like: {payload[0].payload.feels_like}°C</div>
                                        )}
                                        {view === "pop" && <div>Rain: {payload[0].payload.pop}%</div>}
                                    </motion.div>
                                ) : null
                            }
                        />
                        {(view === "temp" || view === "both") &&
                            <Line
                                type="monotone"
                                dataKey="temp"
                                stroke="#2563eb"
                                strokeWidth={2}
                                dot={{ r: 3 }}
                                activeDot={{ r: 6 }}
                                isAnimationActive
                            />}
                        {(view === "feels_like" || view === "both") &&
                            <Line
                                type="monotone"
                                dataKey="feels_like"
                                stroke="#0ea5e9"
                                strokeWidth={2}
                                dot={{ r: 3 }}
                                activeDot={{ r: 6 }}
                                isAnimationActive
                            />}
                        {view === "pop" &&
                            <Line
                                type="monotone"
                                dataKey="pop"
                                stroke="#eab308"
                                strokeWidth={2}
                                dot={{ r: 3 }}
                                activeDot={{ r: 6 }}
                                isAnimationActive
                            />}
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
};

export default HourlyTemperature;

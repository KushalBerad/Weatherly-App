// import { Skeleton } from "./skeleton";

// function WeatherSkeleton() {
//     return (
//         <div className="space-y-6">
//         <div className="grid gap -6">
//             <Skeleton className="h-[300px] w-full rounded-lg" />
//             <Skeleton className="h-[300px] w-full rounded-lg" />
//             <div className="grid gap-6 md:grid-cols-2">
//                 <Skeleton className="h-[300px] w-full rounded-lg" />
//                 <Skeleton className="h-[300px] w-full rounded-lg" />
//             </div>
//         </div>
//         </div>
//     );
// }

// export default WeatherSkeleton;






import { Skeleton } from "./skeleton";
import { motion } from "framer-motion";

function WeatherSkeleton() {
    return (
        <motion.div
            className="space-y-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            aria-busy="true"
        >
            <div className="grid gap-6">
                <Skeleton className="h-[300px] w-full rounded-lg" />
                <Skeleton className="h-[56px] w-full rounded-lg" />
            </div>
            <div className="grid gap-6 md:grid-cols-2">
                <Skeleton className="h-[180px] w-full rounded-lg" />
                <Skeleton className="h-[180px] w-full rounded-lg" />
            </div>
        </motion.div>
    );
}

export default WeatherSkeleton;

import type { GeocodingResponse, WeatherData } from "@/api/types";
import { Card, CardContent } from "./card";
import {
    ArrowDown,
    ArrowUp,
    Droplets,
    Wind,
    Sun,
    Moon,
    Thermometer,
    Gauge,
} from "lucide-react";
import { motion } from "framer-motion";

interface CurrentWeatherProps {
    data: WeatherData;
    locationName?: GeocodingResponse;
}

const CurrentWeather = ({ data, locationName }: CurrentWeatherProps) => {
    const {
        weather: [currentWeather],
        main: { temp, feels_like, temp_min, temp_max, humidity, pressure },
        wind: { speed },
        sys: { sunrise, sunset },
        visibility,
    } = data;

    const formatTemp = (t: number) => `${Math.round(t)}°C`;
    const formatTime = (timestamp: number) =>
        new Date(timestamp * 1000).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
        });

    return (
        <Card className="overflow-hidden bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 shadow-xl">
            <CardContent className="p-6">
                <div className="grid gap-6 md:grid-cols-2 items-center">
                    {/* Left side */}
                    <div className="space-y-6">
                        {/* Location */}
                        <div>
                            <h2 className="text-3xl font-bold tracking-tight">
                                {locationName?.name}
                                {locationName?.state && (
                                    <span className="text-muted-foreground">, {locationName.state}</span>
                                )}
                            </h2>
                            <p className="text-sm text-muted-foreground">{locationName?.country}</p>
                        </div>

                        {/* Temperature + feels like */}
                        <div className="flex items-center gap-6">
                            <p className="text-6xl font-bold tracking-tighter">{formatTemp(temp)}</p>
                            <div className="space-y-1">
                                <p className="text-sm font-medium text-muted-foreground">
                                    Feels Like {formatTemp(feels_like)}
                                </p>
                                <div className="flex gap-3 text-sm font-medium">
                                    <span className="flex items-center gap-1 text-blue-500">
                                        <ArrowDown className="h-4 w-4" />
                                        {formatTemp(temp_min)}
                                    </span>
                                    <span className="flex items-center gap-1 text-red-500">
                                        <ArrowUp className="h-4 w-4" />
                                        {formatTemp(temp_max)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Weather metrics */}
                        <div className="grid grid-cols-2 gap-6">
                            <div className="flex items-center gap-2">
                                <Droplets className="h-5 w-5 text-blue-500" />
                                <div>
                                    <p className="text-sm font-medium">Humidity</p>
                                    <p className="text-sm text-muted-foreground">{humidity}%</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-2">
                                <Wind className="h-5 w-5 text-blue-500" />
                                <div>
                                    <p className="text-sm font-medium">Wind</p>
                                    <p className="text-sm text-muted-foreground">{speed} m/s</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-2">
                                <Gauge className="h-5 w-5 text-blue-500" />
                                <div>
                                    <p className="text-sm font-medium">Pressure</p>
                                    <p className="text-sm text-muted-foreground">{pressure} hPa</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-2">
                                <Thermometer className="h-5 w-5 text-blue-500" />
                                <div>
                                    <p className="text-sm font-medium">Visibility</p>
                                    <p className="text-sm text-muted-foreground">
                                        {Math.round(visibility / 1000)} km
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Sunrise / Sunset */}
                        <div className="flex gap-6">
                            <div className="flex items-center gap-2">
                                <Sun className="h-5 w-5 text-yellow-500" />
                                <p className="text-sm font-medium">
                                    Sunrise {formatTime(sunrise)}
                                </p>
                            </div>
                            <div className="flex items-center gap-2">
                                <Moon className="h-5 w-5 text-indigo-500" />
                                <p className="text-sm font-medium">
                                    Sunset {formatTime(sunset)}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Right side (icon + description) */}
                    <motion.div
                        className="flex flex-col items-center justify-center"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.6 }}
                    >
                        <div className="relative flex aspect-square w-full max-w-[200px] items-center justify-center">
                            <img
                                src={`https://openweathermap.org/img/wn/${currentWeather.icon}@4x.png`}
                                alt={currentWeather.description}
                                className="h-full w-full object-contain"
                            />
                            <div className="absolute bottom-0 text-center bg-white/70 dark:bg-gray-900/70 px-2 rounded-md">
                                <p className="text-sm font-medium capitalize">
                                    {currentWeather.description}
                                </p>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </CardContent>
        </Card>
    );
};

export default CurrentWeather;

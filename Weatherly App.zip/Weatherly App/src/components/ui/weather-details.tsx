import type { WeatherData } from "@/api/types";
import { format } from "date-fns";
import { Compass, Gauge, Sunrise, Sunset } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardHeader, CardTitle, CardContent } from "./card";

interface WeatherDetailsProps {
    data: WeatherData;
}

const WeatherDetails = ({ data }: WeatherDetailsProps) => {
    const { main, wind, sys, coord } = data;

    const formatTime = (timestamp: number) =>
        format(new Date(timestamp * 1000), "hh:mm a");

    const getWindDirection = (degree: number) => {
        const directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
        const index = Math.round((((degree % 360) < 0 ? degree + 360 : degree) / 45) % 8);
        return directions[index];
    };

    const details = [
        { title: "Sunrise", value: formatTime(sys.sunrise), icon: Sunrise, color: "text-orange-500" },
        { title: "Sunset", value: formatTime(sys.sunset), icon: Sunset, color: "text-blue-500" },
        { title: "Wind Direction", value: `${getWindDirection(wind.deg)} (${wind.deg}°)`, icon: Compass, color: "text-green-500" },
        { title: "Humidity", value: `${main.humidity}%`, icon: Gauge, color: "text-yellow-500" },
        { title: "Pressure", value: `${main.pressure} hPa`, icon: Gauge, color: "text-purple-500" },
    ];

    return (
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 shadow-xl h-full flex flex-col">
            <CardHeader>
                <CardTitle>Weather Details</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4 flex-1">
                {details.map((detail, idx) => (
                    <motion.div
                        key={detail.title}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.08 }}
                        className={`flex items-center gap-2 p-2 rounded border-l-4 shadow-sm ${detail.color}`}
                    >
                        <detail.icon className="h-5 w-5 mr-2" />
                        <span className="font-semibold">{detail.title}</span>
                        <span className="ml-auto">{detail.value}</span>
                    </motion.div>
                ))}

                {/* Embedded map always sticks to bottom */}
                {coord && (
                    <div className="rounded-xl overflow-hidden shadow mt-auto h-52 w-full border">
                        <iframe
                            title="Weather Map"
                            width="100%"
                            height="100%"
                            style={{ border: 0 }}
                            loading="lazy"
                            src={`https://www.openstreetmap.org/export/embed.html?
                                bbox=${coord.lon - 0.08}%2C${coord.lat - 0.05}%2C$
                                {coord.lon + 0.08}%2C${coord.lat + 0.05}
                                &layer=
                                mapnik&marker=${coord.lat}%2C${coord.lon}`}
                        />
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default WeatherDetails;

import { useTheme } from "@/context/theme-provider";
import { Sun, Moon } from "lucide-react";
import { Link } from "react-router-dom";
import { CitySearch } from "./city-search";
import { useEffect, useState } from "react";

// Custom formatDate function for DD/MM/YYYY
function formatDate(date: Date) {
    const dd = String(date.getDate()).padStart(2, "0");
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const yyyy = date.getFullYear();
    return `${dd}/${mm}/${yyyy}`;
}

const Header = () => {
    const { theme, setTheme } = useTheme();
    const isDark = theme === "dark";
    const [now, setNow] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => setNow(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <header className="w-full sticky top-0 z-50 
            bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-700 
            bg-opacity-90 backdrop-blur-md shadow-lg">
            <div className="flex items-center justify-between px-4 py-4">
                {/* Logo + Title */}
                <Link
                    to="/"
                    className="flex items-center gap-3 font-extrabold text-3xl tracking-wide text-white flex-shrink-0 drop-shadow-md"
                >
                    <img
                        src="/3799766.png"
                        alt="logo"
                        className="h-10 w-10 object-contain"
                        style={{ marginRight: 6 }}
                    />
                    Weatherly
                </Link>

                {/* Date + Time */}
                <div className="flex flex-col items-center flex-grow mx-6 space-y-1">
                    <span className="text-lg font-semibold text-white/90 animate-fade-in">
                        {formatDate(now)},{" "}
                        {now
                            .toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                                hour12: true,
                            })
                            .replace("am", "AM")
                            .replace("pm", "PM")}
                    </span>
                </div>

                {/* Search + Theme Toggle */}
                <div className="flex items-center gap-3">
                    <CitySearch />
                    <button
                        onClick={() => setTheme(isDark ? "light" : "dark")}
                        className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition"
                    >
                        {isDark ? (
                            <Sun className="w-6 h-6 text-yellow-300" />
                        ) : (
                            <Moon className="w-6 h-6 text-indigo-100" />
                        )}
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;

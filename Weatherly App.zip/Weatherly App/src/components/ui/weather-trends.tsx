import { Tabs, TabsContent, TabsList, TabsTrigger } from "@radix-ui/react-tabs";
import HourlyTemperature from "./hourly-temperature";
import WeatherForecast from "./weather-forecast";
import type { ForecastData } from "@/api/types";

interface WeatherTrendsProps {
    forecastData: ForecastData;
}

const WeatherTrends = ({ forecastData }: WeatherTrendsProps) => {
    return (
        <div className="w-full">
            <Tabs defaultValue="hourly" className="w-full">
                <TabsList className="flex justify-center mb-4">
                    <TabsTrigger value="hourly">Hourly</TabsTrigger>
                    <TabsTrigger value="daily">5-Day</TabsTrigger>
                </TabsList>

                <TabsContent value="hourly">
                    <HourlyTemperature data={forecastData} />
                </TabsContent>

                <TabsContent value="daily">
                    <WeatherForecast data={forecastData} />
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default WeatherTrends;

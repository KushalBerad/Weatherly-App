import type { Coordinates } from "@/api/types";
import { useEffect, useState } from "react";

interface GeolocationState {
    coordinates: Coordinates | null;
    error: string | null;
    isLoading: boolean;
}

export function useGeolocation(defaultCoords: Coordinates = { lat: 28.6139, lon: 77.2090 }) {
    const [locationData, setLocationData] = useState<GeolocationState>({
        coordinates: null,
        error: null,
        isLoading: true,
    });

    const getLocation = () => {
        setLocationData((prev) => ({ ...prev, isLoading: true, error: null }));

        if (!navigator.geolocation) {
            setLocationData({
                coordinates: defaultCoords,
                error: "Geolocation is not supported. Showing default city.",
                isLoading: false,
            });
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                setLocationData({
                    coordinates: { lat: latitude, lon: longitude },
                    error: null,
                    isLoading: false,
                });
            },
            (error) => {
                let errormessage = "";
                switch (error.code) {
                    case error.PERMISSION_DENIED:
                        errormessage = "User denied location. Showing default city.";
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errormessage = "Location unavailable. Showing default city.";
                        break;
                    case error.TIMEOUT:
                        errormessage = "Location request timed out. Showing default city.";
                        break;
                    default:
                        errormessage = "Unknown error. Showing default city.";
                }
                setLocationData({
                    coordinates: defaultCoords,
                    error: errormessage,
                    isLoading: false,
                });
            },
            {
                enableHighAccuracy: true,
                timeout: 10000, // longer timeout
                maximumAge: 60000, // allow cached position for 1 min
            }
        );
    };

    useEffect(() => {
        getLocation();
    }, []);

    return { ...locationData, getLocation };
}

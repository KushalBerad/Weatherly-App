import type { Coordinates } from "@/api/types";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY;

// -----------------------------
// API Client
// -----------------------------
const api = axios.create({
    baseURL: "https://api.openweathermap.org",
    timeout: 8000, // ⏳ fail fast if API is slow
});

// -----------------------------
// API Functions
// -----------------------------
export const weatherAPI = {
    async SearchLocations(query: string) {
        if (!query || query.length < 2) return [];
        try {
            const { data } = await api.get(`/geo/1.0/direct`, {
                params: { q: query, limit: 5, appid: API_KEY },
            });
            return data.map((item: any) => ({
                id: `${item.lat}-${item.lon}`,
                name: item.name,
                state: item.state || "",
                country: item.country,
                lat: item.lat,
                lon: item.lon,
            }));
        } catch (e) {
            console.error("❌ Location search failed:", e);
            return [];
        }
    },

    async getCurrentWeather({ lat, lon }: Coordinates) {
        const { data } = await api.get(`/data/2.5/weather`, {
            params: { lat, lon, appid: API_KEY, units: "metric" },
        });
        return data;
    },

    async getForecast({ lat, lon }: Coordinates) {
        const { data } = await api.get(`/data/2.5/forecast`, {
            params: { lat, lon, appid: API_KEY, units: "metric" },
        });
        return data;
    },

    async reverseGeocode({ lat, lon }: Coordinates) {
        const { data } = await api.get(`/geo/1.0/reverse`, {
            params: { lat, lon, limit: 1, appid: API_KEY },
        });
        return data[0];
    },
};

// -----------------------------
// Query Keys
// -----------------------------
export const WEATHER_KEYS = {
    weather: (coords: Coordinates) => ["weather", coords] as const,
    forecast: (coords: Coordinates) => ["forecast", coords] as const,
    location: (coords: Coordinates) => ["location", coords] as const,
    search: (query: string) => ["location-search", query] as const,
} as const;

// -----------------------------
// Hooks
// -----------------------------
export function useWeatherQuery(coordinates: Coordinates | null) {
    return useQuery({
        queryKey: WEATHER_KEYS.weather(coordinates ?? { lat: 0, lon: 0 }),
        queryFn: () => (coordinates ? weatherAPI.getCurrentWeather(coordinates) : null),
        enabled: !!coordinates,
        staleTime: 1000 * 60 * 5, // cache for 5 min
    });
}

export function useForecastQuery(coordinates: Coordinates | null) {
    return useQuery({
        queryKey: WEATHER_KEYS.forecast(coordinates ?? { lat: 0, lon: 0 }),
        queryFn: () => (coordinates ? weatherAPI.getForecast(coordinates) : null),
        enabled: !!coordinates,
        staleTime: 1000 * 60 * 5,
    });
}

export function useReverseGeocodeQuery(coordinates: Coordinates | null) {
    return useQuery({
        queryKey: WEATHER_KEYS.location(coordinates ?? { lat: 0, lon: 0 }),
        queryFn: () => (coordinates ? weatherAPI.reverseGeocode(coordinates) : null),
        enabled: !!coordinates,
        staleTime: 1000 * 60 * 10,
    });
}

export function useLocationSearch(query: string) {
    return useQuery({
        queryKey: WEATHER_KEYS.search(query),
        queryFn: () => weatherAPI.SearchLocations(query),
        enabled: query.length >= 2,
        staleTime: 1000 * 60 * 60, // cache results for 1h
    });
}
